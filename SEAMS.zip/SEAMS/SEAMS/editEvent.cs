﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace SEAMS
{
    public partial class editEvent : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;
        public editEvent()
        {
            InitializeComponent();
        }
        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void editEvent_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                if (eventPage.action == "view")
                {
                    txtName.ReadOnly = true;
                    txtLoc.ReadOnly = true;
                    cbType.DropDownStyle = ComboBoxStyle.DropDownList;
                    btnAdd.Text = "OK";
                    btnAdd.Location = new Point(158, 366);
                    btnCancel.Visible = false;
                }
                else if (eventPage.action == "edit")
                {
                    btnAdd.Text = "OK";
                }

                lblID.Text = eventPage.eventID;
                txtName.Text = eventPage.eventname;
                txtLoc.Text = eventPage.loc;
                cbType.Text = eventPage.category;

                dt = executeQuery(String.Format("SELECT event_id, name,location,type,date,starttime,endtime,deptno FROM event WHERE event_id = '{0}'", eventPage.eventID));

                string date = dt.Rows[0]["date"].ToString();

                DateTimeFormatInfo dateTimeFormat = new DateTimeFormatInfo();
                dateTimeFormat.ShortDatePattern = "MM/dd/yyyy";

                DateTime dateTime = DateTime.ParseExact(date, "MM/dd/yyyy", dateTimeFormat);
                dtDate.Value = dateTime;

                string starttime = dt.Rows[0]["starttime"].ToString();
                string endtime = dt.Rows[0]["endtime"].ToString();

                DateTime time;

                if (DateTime.TryParseExact(starttime, "hh:mm tt", CultureInfo.InvariantCulture, DateTimeStyles.None, out time)) dtSTime.Value = time;
                else MessageBox.Show("An error has occurred. Can't display the start time.");

                if (DateTime.TryParseExact(endtime, "hh:mm tt", CultureInfo.InvariantCulture, DateTimeStyles.None, out time)) dtETime.Value = time;
                else MessageBox.Show("An error has occurred. Can't display the end time.");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (eventPage.action == "edit")
            {
                try
                {
                    string date = dtDate.Value.Date.ToString("MM/dd/yyyy"); ;
                    string stime = dtSTime.Value.ToString("hh:mm tt");
                    string etime = dtETime.Value.ToString("hh:mm tt");
                    
                    dt = executeQuery(String.Format("UPDATE event SET name = '{0}', location = '{1}', type = '{2}', date = '{3}', starttime = '{4}', endtime = '{5}' WHERE event_id = '{6}'", txtName.Text, txtLoc.Text, cbType.Text, date, stime, etime, eventPage.eventID));

                    MessageBox.Show("Update succesfully.");
                    editStudent.ActiveForm.Close();
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                editStudent.ActiveForm.Close();
            }

        }

        private void Time_ValueChanged(object sender, EventArgs e)
        {
            dtSTime.CustomFormat = "hh:mm tt";
            dtETime.CustomFormat = "hh:mm tt";
        }
    }
}
