﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class studPage : UserControl
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        public static string studno, lname, fname, mname,action;
        public studPage()
        {
            InitializeComponent();
        }

        private void btnAddStud_Click(object sender, EventArgs e)
        {
            addStudent addStudent = new addStudent();
            addStudent.StudPageForm = this; 
            addStudent.Show();
        }

        private void studPage_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();
                cbSelect.Text = "--PLEASE SELECT--";
                btnRefresh_Click(sender,e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void dgvStudents_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    DataGridViewColumn clickedColumn = dgvStudents.Columns[e.ColumnIndex];

                    if (clickedColumn.HeaderText == "View")
                    {
                        action = "view";
                        studno = dgvStudents.Rows[e.RowIndex].Cells["stud_id"].Value.ToString();
                        lname = dgvStudents.Rows[e.RowIndex].Cells["lastname"].Value.ToString();
                        fname = dgvStudents.Rows[e.RowIndex].Cells["firstname"].Value.ToString();
                        mname = dgvStudents.Rows[e.RowIndex].Cells["midname"].Value.ToString();
                        editStudent view = new editStudent();
                        view.Show();

                    }
                    else if (clickedColumn.HeaderText == "Edit")
                    {
                        action = "edit";
                        studno = dgvStudents.Rows[e.RowIndex].Cells["stud_id"].Value.ToString();
                        lname = dgvStudents.Rows[e.RowIndex].Cells["lastname"].Value.ToString();
                        fname = dgvStudents.Rows[e.RowIndex].Cells["firstname"].Value.ToString();
                        mname = dgvStudents.Rows[e.RowIndex].Cells["midname"].Value.ToString();
                        editStudent edit = new editStudent();
                        edit.Show();
                    }
                    else if (clickedColumn.HeaderText == "Delete")
                    {
                        
                        DialogResult result = MessageBox.Show("Are you sure you want to delete this?", "Confirmation", MessageBoxButtons.YesNo);
                        
                        if (result == DialogResult.Yes)
                        {
                            executeQuery(String.Format("DELETE FROM student WHERE stud_id = '{0}'", dgvStudents.Rows[e.RowIndex].Cells["stud_id"].Value.ToString()));
                            executeQuery(String.Format("DELETE FROM admin WHERE admin_id = '{0}'", dgvStudents.Rows[e.RowIndex].Cells["stud_id"].Value.ToString()));
                            dt = executeQuery(String.Format("SELECT stud_id FROM student WHERE stud_id = '{0}'", dgvStudents.Rows[e.RowIndex].Cells["stud_id"].Value.ToString()));
                            
                            if(dt.Rows.Count == 0)
                            {
                                MessageBox.Show("Data Successfully Deleted.");
                                btnRefresh_Click(sender, e);
                            }
                            else
                            {
                                MessageBox.Show("Deletion Failed");
                            }
                        }
                        else if (result == DialogResult.No)
                        {
                            MessageBox.Show("Deletion was not continued.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void pbSearch_Click(object sender, EventArgs e)
        {
            string searchBy = cbSelect.Text;
            string search = txtSearch.Text;

            if (searchBy.Length == 0 || search.Length == 0) 
            {
                MessageBox.Show("All fields must not be empty.");
                cbSelect.Focus();
            } 
            else
            {
                if(searchBy == "--PLEASE SELECT--")
                {
                    MessageBox.Show("Invalid Search By");
                    cbSelect.Focus();
                }
                else
                {
                    if (searchBy == "LAST NAME") searchBy = "lastname";
                    else if (searchBy == "FIRST NAME") searchBy = "firstname";
                    else if (searchBy == "MIDDLE NAME") searchBy = "midname";
                    else if (searchBy == "ID NUMBER") searchBy = "stud_id";
                }

                dt = executeQuery(String.Format("SELECT stud_id,lastname,firstname, midname FROM student WHERE {0} LIKE '{1}'", searchBy, search));

                if (dt.Rows.Count > 0)
                {
                    dgvStudents.DataSource = dt;
                    dgvStudents.Refresh();
                    cbSelect.Text = "--PLEASE SELECT--";
                    txtSearch.Text = "";
                }
                else
                {
                    MessageBox.Show("Student doesn't exist.");
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvStudents.Font = new Font("Verdana", 8);
            dt = executeQuery("SELECT stud_id,lastname,firstname,midname FROM student");
            dgvStudents.DataSource = dt;
            dgvStudents.Refresh();
        }


    }
}
