﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class Form1 : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        public static string studId, name;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();
                btnStudLogin.BackColor = Color.FromArgb(38, 87, 22);
                btnStudLogin.FlatAppearance.BorderColor = Color.FromArgb(38, 87, 22);
                btnStudLogin.ForeColor = Color.White;
                txtStudID.Focus();

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnAdLogin_Click(object sender, EventArgs e)
        {
            btnAdLogin.BackColor = Color.FromArgb(38, 87, 22);
            btnAdLogin.FlatAppearance.BorderColor = Color.FromArgb(38, 87, 22);
            btnAdLogin.ForeColor = Color.White;

            btnStudLogin.BackColor = Color.FromArgb(255, 251, 206);
            btnStudLogin.FlatAppearance.BorderColor = Color.FromArgb(255, 251, 206);
            btnStudLogin.ForeColor = Color.Black;
            
            pnlStudLogin.Visible = false;
            adminLogin adLogin = new adminLogin();
            adLogin.Location = new Point(396, 114);
            adLogin.Anchor = AnchorStyles.Bottom;
            adLogin.Anchor = AnchorStyles.Right;
            this.Controls.Add(adLogin);
            adLogin.Show();

        }

        private void btnStudLogin_Click(object sender, EventArgs e)
        {
            btnStudLogin.BackColor = Color.FromArgb(38, 87, 22);
            btnStudLogin.FlatAppearance.BorderColor = Color.FromArgb(38, 87, 22);
            btnStudLogin.ForeColor = Color.White;

            btnAdLogin.BackColor = Color.FromArgb(255, 251, 206);
            btnAdLogin.FlatAppearance.BorderColor = Color.FromArgb(255, 251, 206);
            btnAdLogin.ForeColor = Color.Black;

            pnlStudLogin.Visible = true;
            pnlStudLogin.BringToFront();

            txtStudID.Focus();
        }

        private void pbShow_Click(object sender, EventArgs e)
        {
            if(txtPass.PasswordChar == '●')
            {
                pbHide.BringToFront();
                txtPass.PasswordChar = '\0';
            }
        }

        private void pbHide_Click(object sender, EventArgs e)
        {
            if (txtPass.PasswordChar == '\0')
            {
                pbShow.BringToFront();
                txtPass.PasswordChar = '●';
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            studId = txtStudID.Text;
            string pass = txtPass.Text;
            string lname, fname, mname;

            if (studId.Length == 0 && pass.Length == 0)
            {
                MessageBox.Show("All fields must not be empty.");
                txtStudID.Focus();
            }
            else
            {
                dt = executeQuery(String.Format("SELECT stud_id FROM student WHERE stud_id = '{0}'", studId));

                if (dt.Rows.Count > 0)
                {
                    dt = executeQuery(String.Format("SELECT stud_id,password,lastname,firstname,midname FROM student WHERE stud_id = '{0}' AND password = '{1}'", studId, pass));
                    if (dt.Rows.Count > 0)
                    {
                        lname = dt.Rows[0]["lastname"].ToString();
                        fname = dt.Rows[0]["firstname"].ToString();
                        mname = dt.Rows[0]["midname"].ToString();
                        name = lname + ", " + fname + " " + mname[0] + ".";
                        studAcct studAcct = new studAcct();
                        studAcct.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect password.");
                    }

                }
                else
                {
                    MessageBox.Show("You are not an enrolled student.");
                }
            }
        }
    }
}
