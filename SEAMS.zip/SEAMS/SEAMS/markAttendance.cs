﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class markAttendance : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        public static string eventID, eventname, name, studno, prog, yrlvl,stat,pageName;

        private void pbExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbSearch_Click(object sender, EventArgs e)
        {
            string searchBy = cbSelect.Text;
            string search = txtSearch.Text;

            try
            {
                if (searchBy == "ID NUMBER") searchBy = "s.stud_id";
                else searchBy = "name";

                dt = executeQuery(String.Format("SELECT s.stud_id, CONCAT(lastname,', ',firstname,' ',midname,'.') AS name, yrlevel,progcode,status FROM student s, program p, attendance a,event e WHERE (s.stud_id = a.stud_id) AND (s.progno = p.progno) AND (e.event_id = a.event_id) AND {0} = '{1}'", searchBy,search));

                dgvAttendance.DataSource = dt;
                dgvAttendance.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public markAttendance()
        {
            InitializeComponent();
        }

        private void markAttendance_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                lblID.Text = eventPage.eventID;
                lblName.Text = eventPage.eventname;

                dt = executeQuery(String.Format("SELECT event_id FROM attendance WHERE event_id = '{0}'", eventPage.eventID));
                if (dt.Rows.Count>0)
                {
                    dgvAttendance.ClearSelection();
                }
                else
                {
                    executeQuery(String.Format("INSERT INTO attendance (stud_id, event_id, status, timestamp) SELECT stud_id, '{0}', 'ABSENT', NOW() FROM student", eventPage.eventID)); 
                    cbSelect.Focus();
                }
                btnRefresh_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dt = executeQuery(String.Format("SELECT s.stud_id, CONCAT(lastname,', ',firstname,' ',midname,'.') AS name, yrlevel,progcode,status FROM student s, program p, attendance a WHERE (s.stud_id = a.stud_id) AND (s.progno = p.progno) AND a.event_id = '{0}'", eventPage.eventID));
            dgvAttendance.DataSource = dt;
            dgvAttendance.Refresh();
            cbSelect.Text = "--PLEASE SELECT--";
            txtSearch.Text = " ";
        }

        private void dgvAttendance_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    DataGridViewColumn clickedColumn = dgvAttendance.Columns[e.ColumnIndex];
                    eventID = lblID.Text;
                    eventname = lblName.Text;
                    pageName = "fromAttendance";
                    name = dgvAttendance.Rows[e.RowIndex].Cells["studname"].Value.ToString();
                    studno = dgvAttendance.Rows[e.RowIndex].Cells["stud_id"].Value.ToString();
                    prog = dgvAttendance.Rows[e.RowIndex].Cells["progcode"].Value.ToString();
                    yrlvl = dgvAttendance.Rows[e.RowIndex].Cells["yrlevel"].Value.ToString();
                    stat = dgvAttendance.Rows[e.RowIndex].Cells["status"].Value.ToString();

                    if (clickedColumn.HeaderText == "View")
                    {
                        viewStudAttendance view = new viewStudAttendance();
                        view.Show();

                    }
                    else if (clickedColumn.HeaderText == "Tag")
                    {
                        DialogResult result = MessageBox.Show("Tag " + name + " as PRESENT?", "Confirmation", MessageBoxButtons.YesNo);

                        if (result == DialogResult.Yes)
                        {
                            executeQuery(String.Format("UPDATE attendance SET status = 'PRESENT' WHERE stud_id = '{0}'", studno));
                            btnRefresh_Click(sender, e);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
