﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class adminPage : UserControl
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        public static string adminId, lname, fname,mname,deptcode;
        public adminPage()
        {
            InitializeComponent();
        }
        private void adminPage_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();
                btnRefresh_Click(sender, e);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvStudents.Font = new Font("Verdana", 8);
            dt = executeQuery("SELECT stud_id,lastname,firstname,midname FROM student");
            dgvStudents.DataSource = dt;
            dgvStudents.Refresh();

            dt = executeQuery("SELECT admin_id,lastname,position,deptcode AS department FROM student s, admin a, department d WHERE (admin_id = stud_id) AND (a.deptno = d.deptno)");
            dgvAdmins.DataSource = dt;
            dgvAdmins.Refresh();
        }

        private void pbSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text;

            if (search.Length == 0)
            {
                MessageBox.Show("Please enter ID number.");
                txtSearch.Focus();
            }
            else
            {
                try
                {
                    dt = executeQuery(String.Format("SELECT stud_id, lastname, firstname, midname FROM student WHERE stud_id LIKE '{0}'", search));

                    if (dt.Rows.Count > 0)
                    {
                        dgvStudents.DataSource = dt;
                        dgvStudents.Refresh();
                        txtSearch.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Student doesn't exist.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void dgvStudents_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    DataGridViewColumn clickedColumn = dgvStudents.Columns[e.ColumnIndex];

                    if (clickedColumn.HeaderText == "Add")
                    {
                        adminId = dgvStudents.Rows[e.RowIndex].Cells["stud_id"].Value.ToString();
                        lname = dgvStudents.Rows[e.RowIndex].Cells["lastname"].Value.ToString();
                        fname = dgvStudents.Rows[e.RowIndex].Cells["firstname"].Value.ToString();
                        mname = dgvStudents.Rows[e.RowIndex].Cells["midname"].Value.ToString();
                        
                        addAdmin addAdmin = new addAdmin();
                        addAdmin.AdPageForm = this;
                        addAdmin.Show();
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
