﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class addAdmin : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        private adminPage adPageForm;
       
        public addAdmin()
        {
            InitializeComponent();
        }

        public adminPage AdPageForm
        {
            get { return adPageForm; }
            set { adPageForm = value; }
        }

        private void addAdmin_Load(object sender, EventArgs e)
        {
            
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                dt = executeQuery(String.Format("SELECT stud_id,lastname,firstname,midname,progcode,deptcode FROM student s, program p, department d WHERE p.progno = s.progno AND p.deptno = d.deptno AND stud_id = '{0}'", adminPage.adminId));

                lblID.Text = adminPage.adminId;
                txtFName.Text = adminPage.fname;
                txtMName.Text = adminPage.mname;
                txtLName.Text = adminPage.lname;
                cbPos.Text = "--PLEASE SELECT--";
                cbDept.Text = dt.Rows[0]["deptcode"].ToString();

                cbPos.Focus();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string adminID, lname, position, dept,pass;

            adminID = lblID.Text;
            lname = adminPage.lname;
            position = cbPos.Text;
            dept = cbDept.Text;
            pass = "admin" + adminID;

            try
            {
                if (cbPos.Text == "--PLEASE SELECT--")
                {
                    MessageBox.Show("Invalid Position.");
                    cbPos.Focus();
                }
                else
                {
                    DialogResult result = MessageBox.Show("Are you sure you want to add this student as an admin?", "Confirmation", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        dt = executeQuery(String.Format("SELECT deptno, deptcode FROM department d WHERE deptcode = '{0}'", dept));

                        dept = dt.Rows[0]["deptno"].ToString();
                        string deptcode = dt.Rows[0]["deptcode"].ToString();

                        dt = executeQuery(String.Format("SELECT deptno, position FROM admin WHERE deptno = '{0}' AND position = '{1}'", dept, position));

                        if (dt.Rows.Count > 0)
                        {
                            MessageBox.Show(String.Format("There is already a {0} officer for {1}. Please indicate another position.",position,deptcode));
                            cbPos.Focus();
                        }
                        else
                        {
                            executeQuery(String.Format("INSERT INTO admin (admin_id,deptno,password, position) VALUES ('{0}','{1}','{2}','{3}')", adminID, dept, pass, position));

                            dt = executeQuery(String.Format("SELECT admin_id FROM admin WHERE admin_id = '{0}'", adminID));

                            if (dt.Rows.Count > 0)
                            {
                                MessageBox.Show("New admin successfully added.");
                                executeQuery(String.Format("SELECT admin_id, lastname, position, deptcode FROM admin a, student s, department d WHERE (admin_id = stud_id) AND (a.deptno = d.deptno)"));
                                adPageForm.dgvAdmins.DataSource = dt;
                                adPageForm.dgvAdmins.Refresh();
                                addAdmin.ActiveForm.Close();
                            }
                            else
                            {
                                MessageBox.Show("New admin can't be added.");
                            }
                        }
                    }
                    else if (result == DialogResult.No)
                    {
                        MessageBox.Show("Deletion was not continued.");
                        addAdmin.ActiveForm.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            addAdmin.ActiveForm.Close();
        }
    }
}
