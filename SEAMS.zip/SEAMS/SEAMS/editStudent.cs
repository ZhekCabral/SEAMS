﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class editStudent : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;
        public editStudent()
        {
            InitializeComponent();
        }

        private void editStudent_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                if (studPage.action == "view")
                {
                    txtLName.ReadOnly = true;
                    txtFName.ReadOnly = true;
                    txtMName.ReadOnly = true;
                    cbGender.DropDownStyle = ComboBoxStyle.DropDownList;
                    cbYrLevel.DropDownStyle = ComboBoxStyle.DropDownList;
                    cbProg.DropDownStyle = ComboBoxStyle.DropDownList;
                    txtPass.ReadOnly = true;
                    btnOK.Text = "OK";
                    btnOK.Location = new Point(158, 366);
                    btnCancel.Visible = false;
                }

                lblID.Text = studPage.studno;
                txtLName.Text = studPage.lname;
                txtFName.Text = studPage.fname;
                txtMName.Text = studPage.mname;

                dt = executeQuery(String.Format("SELECT stud_id,lastname,firstname,midname,gender,yrlevel,p.progno, progcode,password FROM student s, program p WHERE (s.progno = p.progno) AND stud_id = '{0}'", studPage.studno));

                if (dt.Rows.Count > 0)
                {
                    cbGender.Text = dt.Rows[0]["gender"].ToString();
                    cbYrLevel.Text = dt.Rows[0]["yrlevel"].ToString();
                    cbProg.Text = dt.Rows[0]["progcode"].ToString();
                    txtPass.Text = dt.Rows[0]["password"].ToString();
                }
                else
                {
                    MessageBox.Show("Failed to find the student selected");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (studPage.action == "edit")
            {
                try
                {
                    dt = executeQuery(String.Format("SELECT progno, progcode FROM program WHERE progcode = '{0}'", cbProg.Text));
                    string progno = dt.Rows[0]["progno"].ToString();

                    dt = executeQuery(String.Format("UPDATE student SET lastname = '{0}',firstname = '{1}', midname = '{2}', gender = '{3}', yrlevel = '{4}', progno = '{5}', password = '{6}' WHERE stud_id = '{7}'", txtLName.Text, txtFName.Text, txtMName.Text, cbGender.Text, cbYrLevel.Text, progno, txtPass.Text, studPage.studno));

                    MessageBox.Show("Data updated succesfully.");
                    editStudent.ActiveForm.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed update\n" + ex.Message);
                }
            }
            else
            {
                editStudent.ActiveForm.Close();
            }
            
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            editStudent.ActiveForm.Close();
        }
    }
}
