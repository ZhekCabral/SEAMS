﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class eventPage : UserControl
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        public static string eventID, eventname, category, loc, action,pageName;
        public eventPage()
        {
            InitializeComponent();
        }

        private void eventPage_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();
                cbSelect.Text = "--PLEASE SELECT--";
                btnRefresh_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pbSearch_Click(object sender, EventArgs e)
        {
            string searchBy = cbSelect.Text;
            string search = txtSearch.Text;

            if (searchBy.Length == 0 || search.Length == 0)
            {
                MessageBox.Show("All fields must not be empty.");
                cbSelect.Focus();
            }
            else
            {
                if (searchBy == "--PLEASE SELECT--")
                {
                    MessageBox.Show("Invalid Search By");
                    cbSelect.Focus();
                }
                else
                {
                    if (searchBy == "EVENT ID") searchBy = "event_id";
                    else if (searchBy == "EVENT NAME") searchBy = "name";
                }

                dt = executeQuery(String.Format("SELECT event_id, name, location, type FROM event WHERE {0} LIKE '{1}'", searchBy, search));

                if (dt.Rows.Count > 0)
                {
                    dgvEvents.DataSource = dt;
                    dgvEvents.Refresh();
                    cbSelect.Text = "--PLEASE SELECT--";
                    txtSearch.Text = "";
                }
                else
                {
                    MessageBox.Show("Event doesn't exist.");
                }
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvEvents.Font = new Font("Verdana", 8);
            dt = executeQuery("SELECT event_id,name,location,type FROM event");
            dgvEvents.DataSource = dt;
            dgvEvents.Refresh();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            addEvent addEvent = new addEvent();
            addEvent.EventPageForm = this;
            addEvent.Show();
        }

        private void dgvEvents_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    DataGridViewColumn clickedColumn = dgvEvents.Columns[e.ColumnIndex];

                    if (clickedColumn.HeaderText == "View")
                    {
                        action = "view";
                        pageName = "eventPage";
                        eventID = dgvEvents.Rows[e.RowIndex].Cells["event_id"].Value.ToString();
                        eventname = dgvEvents.Rows[e.RowIndex].Cells["name"].Value.ToString();
                        loc = dgvEvents.Rows[e.RowIndex].Cells["location"].Value.ToString();
                        category = dgvEvents.Rows[e.RowIndex].Cells["type"].Value.ToString();
                        editEvent view = new editEvent();
                        view.Show();

                    }
                    else if (clickedColumn.HeaderText == "Edit")
                    {
                        action = "edit";
                        eventID = dgvEvents.Rows[e.RowIndex].Cells["event_id"].Value.ToString();
                        eventname = dgvEvents.Rows[e.RowIndex].Cells["name"].Value.ToString();
                        loc = dgvEvents.Rows[e.RowIndex].Cells["location"].Value.ToString();
                        category = dgvEvents.Rows[e.RowIndex].Cells["type"].Value.ToString();
                        editEvent edit = new editEvent();
                        edit.Show();
                    }
                    else if (clickedColumn.HeaderText == "Mark Attendance")
                    {
                        eventID = dgvEvents.Rows[e.RowIndex].Cells["event_id"].Value.ToString();
                        eventname = dgvEvents.Rows[e.RowIndex].Cells["name"].Value.ToString();
                        markAttendance markAttendance = new markAttendance();
                        markAttendance.Show();
                    }
                    else if (clickedColumn.HeaderText == "Delete")
                    {

                        DialogResult result = MessageBox.Show("Are you sure you want to delete this event?", "Confirmation", MessageBoxButtons.YesNo);
                        try
                        {
                            if (result == DialogResult.Yes)
                            {
                                executeQuery(String.Format("DELETE FROM event WHERE event_id = '{0}'", dgvEvents.Rows[e.RowIndex].Cells["event_id"].Value.ToString()));
                                executeQuery(String.Format("DELETE FROM attendance WHERE event_id = '{0}'", dgvEvents.Rows[e.RowIndex].Cells["event_id"].Value.ToString()));
                                dt = executeQuery(String.Format("SELECT event_id FROM event WHERE event_id = '{0}'", dgvEvents.Rows[e.RowIndex].Cells["event_id"].Value.ToString()));

                                if (dt.Rows.Count == 0)
                                {
                                    MessageBox.Show("Data Successfully Deleted.");
                                    btnRefresh_Click(sender, e);
                                }
                                else
                                {
                                    MessageBox.Show("Deletion Failed");
                                }
                            }
                            else if (result == DialogResult.No)
                            {
                                MessageBox.Show("Deletion was not continued.");
                            }
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("Error: Deletion");
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
