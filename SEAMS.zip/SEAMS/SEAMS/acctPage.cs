﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class acctPage : UserControl
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        public static string studno;
        public acctPage()
        {
            InitializeComponent();
        }

        private void acctPage_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                txtLName.ReadOnly = true;
                txtFName.ReadOnly = true;
                txtMName.ReadOnly = true;
                cbGender.Enabled = false;
                cbYrLevel.Enabled = false;
                cbProg.Enabled = false;
                cbPos.Enabled = false;
                txtPass.ReadOnly = true;
                btnUpdate.Enabled = true;
                btnOK.Enabled = false;

                dt = executeQuery(String.Format("SELECT stud_id,lastname,firstname,midname,gender,yrlevel,p.progno, progcode,a.password,position FROM admin a, student s, program p WHERE (s.stud_id = a.admin_id) AND (s.progno = p.progno) AND admin_id = '{0}'", adminAcct.SetValueForAdminID));

                if (dt.Rows.Count > 0)
                {
                    txtLName.Text = dt.Rows[0]["lastname"].ToString();
                    txtFName.Text = dt.Rows[0]["firstname"].ToString();
                    txtMName.Text = dt.Rows[0]["midname"].ToString();
                    cbGender.Text = dt.Rows[0]["gender"].ToString();
                    cbYrLevel.Text = dt.Rows[0]["yrlevel"].ToString();
                    cbProg.Text = dt.Rows[0]["progcode"].ToString();
                    txtPass.Text = dt.Rows[0]["password"].ToString();
                    cbPos.Text = dt.Rows[0]["position"].ToString();
                }
                else
                {
                    MessageBox.Show("Failed to find the student selected");
                }

                dt = executeQuery(String.Format("SELECT event_id,name,location,type FROM event e, department d, admin a WHERE (e.deptno = d.deptno) AND (a.deptno = d.deptno) AND admin_id = '{0}'", adminAcct.SetValueForAdminID));
                dgvSummary.DataSource = dt;
                dgvSummary.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            txtLName.ReadOnly = false;
            txtFName.ReadOnly = false;
            txtMName.ReadOnly = false;
            cbGender.Enabled = true;
            cbYrLevel.Enabled = true;
            cbProg.Enabled = true;
            cbPos.Enabled = true;
            txtPass.ReadOnly = false;
            btnOK.Enabled = true;
            btnUpdate.Enabled = false;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                dt = executeQuery(String.Format("SELECT progno, progcode FROM program WHERE progcode = '{0}'", cbProg.Text));
                string progno = dt.Rows[0]["progno"].ToString();

                dt = executeQuery(String.Format("UPDATE admin a, student s SET lastname = '{0}',firstname = '{1}', midname = '{2}', gender = '{3}', yrlevel = '{4}', progno = '{5}', a.password = '{6}', position = '{7}' WHERE (admin_id = stud_id) AND admin_id = '{8}'", txtLName.Text, txtFName.Text, txtMName.Text, cbGender.Text, cbYrLevel.Text, progno, txtPass.Text,cbPos.Text, adminAcct.SetValueForAdminID));

                MessageBox.Show("Data updated succesfully.");

                txtLName.ReadOnly = true;
                txtFName.ReadOnly = true;
                txtMName.ReadOnly = true;
                cbGender.Enabled = false;
                cbYrLevel.Enabled = false;
                cbProg.Enabled = false;
                cbPos.Enabled = false;
                txtPass.ReadOnly = true;
                btnUpdate.Enabled = true;
                btnOK.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed update\n" + ex.Message);
            }
        }
    }
}
