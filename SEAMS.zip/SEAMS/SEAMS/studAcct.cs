﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace SEAMS
{
    public partial class studAcct : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        public static string SetValueForStudID;
        public studAcct()
        {
            InitializeComponent();
        }

        private void studAcct_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                lblName.Text = Form1.name;
                lblStudID.Text = Form1.studId;

                dt = executeQuery(String.Format("SELECT a.event_id, name, date, status FROM event e, attendance a WHERE (e.event_id = a.event_id) AND stud_id = '{0}'", Form1.studId));
                dgvAttendanceSummary.DataSource = dt;
                dgvAttendanceSummary.Refresh();

                dt = executeQuery(String.Format("SELECT stud_id, p.progno, d.deptno,deptname, deptcode FROM student s, program p, department d WHERE (s.progno = p.progno) AND (p.deptno = d.deptno) AND stud_id = '{0}'", Form1.studId));

                label1.Text = dt.Rows[0]["deptname"].ToString();
                string deptno = dt.Rows[0]["deptno"].ToString();

                dt = executeQuery(String.Format("SELECT admin_id,CONCAT(firstname, ' ', midname, ' ', lastname) AS name,position,deptno FROM admin a, student s WHERE (admin_id = stud_id) AND deptno = '{0}' AND position = 'PRESIDENT'", deptno));

                if (dt.Rows.Count > 0) label4.Text = dt.Rows[0]["name"].ToString();
                else label4.Text = "No President";


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnAcct_Click(object sender, EventArgs e)
        {
            SetValueForStudID = Form1.studId;
            pnlDashboard.Visible = false;
            studAcctPage acctPage = new studAcctPage();
            acctPage.Location = new Point(0, 88);
            acctPage.Anchor = AnchorStyles.Bottom;
            this.Controls.Add(acctPage);
            acctPage.BringToFront();
            acctPage.Show();
        }

        private void btnDash_Click(object sender, EventArgs e)
        {
            pnlDashboard.Visible = true;
            pnlDashboard.BringToFront();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 login = new Form1();
            login.Show();
        }

        private void dgvAttendanceSummary_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0) 
                {
                    DataGridViewRow clickedRow = dgvAttendanceSummary.Rows[e.RowIndex];
                    string cellValue = clickedRow.Cells["event_id"].Value.ToString();

                    dt = executeQuery(String.Format("SELECT event_id, name, location,type,date,starttime,endtime,deptno FROM event WHERE event_id = '{0}'", cellValue));
                    label5.Text = cellValue;
                    txtName.Text = dt.Rows[0]["name"].ToString();
                    txtLoc.Text = dt.Rows[0]["location"].ToString();
                    cbType.Text = dt.Rows[0]["type"].ToString();
                    string date = dt.Rows[0]["date"].ToString();

                    DateTimeFormatInfo dateTimeFormat = new DateTimeFormatInfo();
                    dateTimeFormat.ShortDatePattern = "MM/dd/yyyy";

                    DateTime dateTime = DateTime.ParseExact(date, "MM/dd/yyyy", dateTimeFormat);
                    dtDate.Value = dateTime;

                    string starttime = dt.Rows[0]["starttime"].ToString();
                    string endtime = dt.Rows[0]["endtime"].ToString();

                    DateTime time;

                    if (DateTime.TryParseExact(starttime, "hh:mm tt", CultureInfo.InvariantCulture, DateTimeStyles.None, out time)) dtSTime.Value = time;
                    else MessageBox.Show("An error has occurred. Can't display the start time.");

                    if (DateTime.TryParseExact(endtime, "hh:mm tt", CultureInfo.InvariantCulture, DateTimeStyles.None, out time)) dtETime.Value = time;
                    else MessageBox.Show("An error has occurred. Can't display the end time.");

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
