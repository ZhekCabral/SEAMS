﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    class seams
    {
        public static string con = "server=127.0.0.1;port=3306;database=seams_db;UID=admin;password=cbrlZhkn_440!@;";
        public static string generateID(int digitCount)
        {
            Random random = new Random();
            int min = (int)Math.Pow(10, digitCount - 1);
            int max = (int)Math.Pow(10, digitCount) - 1;
            int id = random.Next(min, max);
            return id.ToString();
        }

    }
}
