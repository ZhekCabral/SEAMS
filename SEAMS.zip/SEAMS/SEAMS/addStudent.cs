﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class addStudent : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        private studPage studPageForm;
        public addStudent()
        {
            InitializeComponent();
        }
        public studPage StudPageForm
        {
            get { return studPageForm; }
            set { studPageForm = value; }
        }
        private void addStudent_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();
                cbGender.Text = "M";
                cbYrLevel.Text = "1";
                cbProg.Text = "--Select Program--";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            string studID, lname, fname, mname, gender, yrlevel, program, pass;

            lname = txtLName.Text;
            fname = txtFName.Text;
            mname = txtMName.Text;
            gender = cbGender.Text;
            yrlevel = cbYrLevel.Text;
            program = cbProg.Text;
            studID = seams.generateID(5);
            pass = lname + studID;

            if (lname.Length == 0 || fname.Length == 0 || mname.Length == 0 || gender.Length == 0 || yrlevel.Length == 0 || program.Length == 0)
            {
                MessageBox.Show("All fields must not be empty");
                txtLName.Focus();
            }
            else
            {
                if (cbProg.Text == "--Select Program--")
                {
                    MessageBox.Show("Program invalid. Please select again.");
                    cbProg.Focus();
                }
                else
                {
                    dt = executeQuery(String.Format("SELECT progno,progname,progcode FROM program WHERE progcode = '{0}'", program));

                    program = dt.Rows[0]["progno"].ToString();

                    executeQuery(String.Format("INSERT INTO student (stud_id, lastname, firstname, midname, gender, yrlevel, progno,password) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", studID, lname, fname, mname, gender, yrlevel, program, pass));

                    dt = executeQuery(String.Format("SELECT stud_id, lastname, firstname, midname FROM student WHERE stud_id = '{0}'", studID));
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("New student successfully added.");
                        dt = executeQuery(String.Format("SELECT stud_id, lastname, firstname, midname FROM student"));
                        studPageForm.dgvStudents.DataSource = dt;
                        studPageForm.dgvStudents.Refresh();
                    }
                    else
                    {
                        MessageBox.Show("New student can't be added.");
                    }

                    addStudent.ActiveForm.Close();
                }
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }        
    }
}
