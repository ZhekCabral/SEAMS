﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class viewStudAttendance : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;
        public viewStudAttendance()
        {
            InitializeComponent();
        }

        private void viewStudAttendance_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                lblStudID.Text = markAttendance.studno;
                txtName.Text = markAttendance.name;
                txtYrLvl.Text = markAttendance.yrlvl;
                txtProg.Text = markAttendance.prog;

                lblEventID.Text = markAttendance.eventID;
                lblEventNme.Text = markAttendance.eventname;
                lblStat.Text = markAttendance.stat;
                btnOK.Focus();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
