﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace SEAMS
{
    public partial class addEvent : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        private eventPage eventPageForm;
        public addEvent()
        {
            InitializeComponent();
        }

        public eventPage EventPageForm
        {
            get { return eventPageForm; }
            set { eventPageForm = value; }
        }

        private void addEvent_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                cbType.Text = "--SELECT TYPE--";
                dtDate.Value = DateTime.Now;
                dtSTime.Value = DateTime.Now;
                dtETime.Value = DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string eventID, name, type, loc, deptno, date,stime, etime;

            dt = executeQuery(String.Format("SELECT deptno,deptcode FROM department WHERE deptcode = '{0}'", adminLogin.dept));
            deptno = dt.Rows[0]["deptno"].ToString();
            name = txtName.Text;
            type = cbType.Text;
            eventID = type.Substring(0, 2) + seams.generateID(3);
            loc = txtLoc.Text;
            date = dtDate.Value.Date.ToString("MM/dd/yyyy");
            stime = dtSTime.Value.ToString("hh:mm tt");
            etime = dtETime.Value.ToString("hh:mm tt");

            try
            {
                if (name.Length == 0 || type.Length == 0 || loc.Length == 0)
                {
                    MessageBox.Show("All fields must not be empty");
                    txtName.Focus();
                }
                else
                {
                    if (cbType.Text == "--Select Program--")
                    {
                        MessageBox.Show("Input invalid. Please select again.");
                        cbType.Focus();
                    }
                    else
                    {
                        executeQuery(String.Format("INSERT INTO event (event_id,name,location,type,date,starttime,endtime,deptno) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", eventID, name, loc, type, date, stime, etime, deptno));

                        dt = executeQuery(String.Format("SELECT event_id,name,location,type FROM event"));
                        if (dt.Rows.Count > 0)
                        {
                            MessageBox.Show("New event successfully added.");
                            eventPageForm.dgvEvents.DataSource = dt;
                            eventPageForm.dgvEvents.Refresh();
                        }
                        else
                        {
                            MessageBox.Show("New event can't be added.");
                        }

                        addStudent.ActiveForm.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            addStudent.ActiveForm.Close();
        }

        private void Time_ValueChanged(object sender, EventArgs e)
        {
            dtSTime.CustomFormat = "hh:mm tt";
            dtETime.CustomFormat = "hh:mm tt";
        }
    }
}
