﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class adminAcct : Form
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        DataTable dt;

        public static string SetValueForAdminID;
        public adminAcct()
        {
            InitializeComponent();
        }

        private void adminAcct_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();

                if (adminLogin.name == "DWCC Admin")
                {
                    lblAdminID.Text = adminLogin.adminId;
                    lblName.Text = adminLogin.name;
                    MessageBox.Show("No admin/student registered. Please register student and admin.");
                }
                else
                {
                    lblAdminID.Text = adminLogin.adminId;
                    lblName.Text = adminLogin.name;
                    string dept = (adminLogin.prog).Substring(0, 2);
                    dt = executeQuery(String.Format("SELECT * FROM student WHERE progno LIKE '{0}%'", dept.Substring(0, 2)));

                    lblStudPopulation.Text = dt.Rows.Count.ToString();

                    dt = executeQuery(String.Format("SELECT event_id,name,location,type FROM event e, department d, admin a WHERE (e.deptno = d.deptno) AND (a.deptno = d.deptno) AND admin_id = '{0}'", adminLogin.adminId));

                    lblNoOfEvents.Text = dt.Rows.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }
        private void btnDash_Click(object sender, EventArgs e)
        {
            pnlDashboard.Visible = true;
            pnlDashboard.BringToFront();
        }

        private void btnEvent_Click(object sender, EventArgs e)
        {
            eventPage ePage = new eventPage();
            ePage.Location = new Point(0, 97);
            showUserControl(ePage);
        }

        private void btnStud_Click(object sender, EventArgs e)
        {
            studPage sPage = new studPage();
            showUserControl(sPage);
        }

       
        private void btnAdmin_Click(object sender, EventArgs e)
        {
            adminPage adPage = new adminPage();
            showUserControl(adPage);
        }

        private void btnAcct_Click(object sender, EventArgs e)
        {
            SetValueForAdminID = adminLogin.adminId;
            acctPage acPage = new acctPage();
            showUserControl(acPage);
        }

        public void showUserControl(UserControl uc)
        {
            pnlDashboard.Visible = false;
            uc.Location = new Point(0, 91);
            uc.Anchor = AnchorStyles.Bottom;
            this.Controls.Add(uc);
            uc.BringToFront();
            uc.Show();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
