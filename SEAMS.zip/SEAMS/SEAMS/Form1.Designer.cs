﻿
namespace SEAMS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnlStudLogin = new System.Windows.Forms.Panel();
            this.btnLogin = new System.Windows.Forms.Button();
            this.pbShow = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.txtStudID = new System.Windows.Forms.TextBox();
            this.pbHide = new System.Windows.Forms.PictureBox();
            this.btnStudLogin = new System.Windows.Forms.Button();
            this.btnAdLogin = new System.Windows.Forms.Button();
            this.pnlSEAMS = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlStudLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbShow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHide)).BeginInit();
            this.pnlSEAMS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlStudLogin
            // 
            this.pnlStudLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlStudLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(252)))), ((int)(((byte)(239)))));
            this.pnlStudLogin.Controls.Add(this.btnLogin);
            this.pnlStudLogin.Controls.Add(this.pbShow);
            this.pnlStudLogin.Controls.Add(this.label2);
            this.pnlStudLogin.Controls.Add(this.label1);
            this.pnlStudLogin.Controls.Add(this.txtPass);
            this.pnlStudLogin.Controls.Add(this.txtStudID);
            this.pnlStudLogin.Controls.Add(this.pbHide);
            this.pnlStudLogin.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlStudLogin.Location = new System.Drawing.Point(396, 114);
            this.pnlStudLogin.Name = "pnlStudLogin";
            this.pnlStudLogin.Size = new System.Drawing.Size(369, 301);
            this.pnlStudLogin.TabIndex = 1;
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(222, 196);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(118, 31);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "LOG IN";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // pbShow
            // 
            this.pbShow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbShow.Image = ((System.Drawing.Image)(resources.GetObject("pbShow.Image")));
            this.pbShow.Location = new System.Drawing.Point(311, 123);
            this.pbShow.Name = "pbShow";
            this.pbShow.Size = new System.Drawing.Size(29, 23);
            this.pbShow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbShow.TabIndex = 4;
            this.pbShow.TabStop = false;
            this.pbShow.Click += new System.EventHandler(this.pbShow_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Student ID:";
            // 
            // txtPass
            // 
            this.txtPass.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPass.Location = new System.Drawing.Point(135, 125);
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '●';
            this.txtPass.Size = new System.Drawing.Size(205, 23);
            this.txtPass.TabIndex = 1;
            // 
            // txtStudID
            // 
            this.txtStudID.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStudID.Location = new System.Drawing.Point(135, 90);
            this.txtStudID.MaxLength = 5;
            this.txtStudID.Name = "txtStudID";
            this.txtStudID.Size = new System.Drawing.Size(205, 23);
            this.txtStudID.TabIndex = 0;
            // 
            // pbHide
            // 
            this.pbHide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbHide.Image = ((System.Drawing.Image)(resources.GetObject("pbHide.Image")));
            this.pbHide.Location = new System.Drawing.Point(311, 123);
            this.pbHide.Name = "pbHide";
            this.pbHide.Size = new System.Drawing.Size(29, 23);
            this.pbHide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbHide.TabIndex = 5;
            this.pbHide.TabStop = false;
            this.pbHide.Click += new System.EventHandler(this.pbHide_Click);
            // 
            // btnStudLogin
            // 
            this.btnStudLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(206)))));
            this.btnStudLogin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(206)))));
            this.btnStudLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStudLogin.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStudLogin.Location = new System.Drawing.Point(396, 83);
            this.btnStudLogin.Name = "btnStudLogin";
            this.btnStudLogin.Size = new System.Drawing.Size(105, 31);
            this.btnStudLogin.TabIndex = 2;
            this.btnStudLogin.Text = "STUDENT";
            this.btnStudLogin.UseVisualStyleBackColor = false;
            this.btnStudLogin.Click += new System.EventHandler(this.btnStudLogin_Click);
            // 
            // btnAdLogin
            // 
            this.btnAdLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(206)))));
            this.btnAdLogin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(251)))), ((int)(((byte)(206)))));
            this.btnAdLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdLogin.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdLogin.Location = new System.Drawing.Point(499, 83);
            this.btnAdLogin.Name = "btnAdLogin";
            this.btnAdLogin.Size = new System.Drawing.Size(105, 31);
            this.btnAdLogin.TabIndex = 3;
            this.btnAdLogin.Text = "ADMIN";
            this.btnAdLogin.UseVisualStyleBackColor = false;
            this.btnAdLogin.Click += new System.EventHandler(this.btnAdLogin_Click);
            // 
            // pnlSEAMS
            // 
            this.pnlSEAMS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(87)))), ((int)(((byte)(22)))));
            this.pnlSEAMS.BackgroundImage = global::SEAMS.Properties.Resources.bg2;
            this.pnlSEAMS.Controls.Add(this.pictureBox1);
            this.pnlSEAMS.Controls.Add(this.label4);
            this.pnlSEAMS.Controls.Add(this.label3);
            this.pnlSEAMS.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSEAMS.Location = new System.Drawing.Point(0, 0);
            this.pnlSEAMS.Name = "pnlSEAMS";
            this.pnlSEAMS.Size = new System.Drawing.Size(358, 450);
            this.pnlSEAMS.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::SEAMS.Properties.Resources.dwcclogo;
            this.pictureBox1.Location = new System.Drawing.Point(83, 83);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(195, 157);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(112, 295);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 19);
            this.label4.TabIndex = 5;
            this.label4.Text = "(Student Module)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(61, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(241, 52);
            this.label3.TabIndex = 5;
            this.label3.Text = "School Event Attendance\r\nManagement System\r\n";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAdLogin);
            this.Controls.Add(this.btnStudLogin);
            this.Controls.Add(this.pnlStudLogin);
            this.Controls.Add(this.pnlSEAMS);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlStudLogin.ResumeLayout(false);
            this.pnlStudLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbShow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHide)).EndInit();
            this.pnlSEAMS.ResumeLayout(false);
            this.pnlSEAMS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlSEAMS;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlStudLogin;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.PictureBox pbShow;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.TextBox txtStudID;
        private System.Windows.Forms.Button btnStudLogin;
        private System.Windows.Forms.Button btnAdLogin;
        private System.Windows.Forms.PictureBox pbHide;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

