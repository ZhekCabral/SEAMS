﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SEAMS
{
    public partial class adminLogin : UserControl
    {
        MySqlDataAdapter dba;
        MySqlConnection con;
        MySqlCommand cmd;
        DataTable dt;

        public static string adminId, name,dept,prog, adminlogin;
        public adminLogin()
        {
            InitializeComponent();
        }

        private void pbShow_Click(object sender, EventArgs e)
        {
            if (txtPass.PasswordChar == '●')
            {
                pbHide.BringToFront();
                txtPass.PasswordChar = '\0';
            }
        }

        private void pbHide_Click(object sender, EventArgs e)
        {
            if (txtPass.PasswordChar == '\0')
            {
                pbShow.BringToFront();
                txtPass.PasswordChar = '●';
            }
        }

        private void lblReg_Click(object sender, EventArgs e)
        {
            adminlogin = "fromLoginForm";
            addAdmin addAdmin = new addAdmin();
            addAdmin.Show();
        }

        private void adminLogin_Load(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(seams.con);
                con.Open();
                txtAdminID.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable executeQuery(string query)
        {
            if (con.State == ConnectionState.Closed) con.Open();

            dba = new MySqlDataAdapter(query, con);
            dt = new DataTable();
            dba.Fill(dt);
            dba.Dispose();
            con.Close();

            return dt;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                dt = executeQuery(String.Format("SELECT * FROM admin"));

                if (dt.Rows.Count == 0)
                {
                    name = "DWCC Admin";
                    adminId = "12345";
                    Form1.ActiveForm.Hide();
                    adminAcct adminAcct = new adminAcct();
                    adminAcct.Show();
                }
                else
                {
                    adminId = txtAdminID.Text;
                    string pass = txtPass.Text;
                    string lname, fname, mname;

                    if (adminId.Length == 0 && pass.Length == 0)
                    {
                        MessageBox.Show("All fields must not be empty.");
                        txtAdminID.Focus();
                    }
                    else
                    {
                        dt = executeQuery(String.Format("SELECT admin_id FROM admin WHERE admin_id = '{0}'", adminId));

                        if (dt.Rows.Count > 0)
                        {
                            dt = executeQuery(String.Format("SELECT admin_id,password FROM admin WHERE admin_id = '{0}' AND password = '{1}'", adminId, pass));
                            if (dt.Rows.Count > 0)
                            {
                                dt = executeQuery(String.Format("SELECT admin_id,lastname,firstname,midname,s.progno AS progno,deptcode FROM student s, program p, department d, admin a WHERE (admin_id = stud_id) AND (p.progno = s.progno) AND (p.deptno = d.deptno) AND admin_id = '{0}'", adminId));
                                lname = dt.Rows[0]["lastname"].ToString();
                                fname = dt.Rows[0]["firstname"].ToString();
                                mname = dt.Rows[0]["midname"].ToString();
                                dept = dt.Rows[0]["deptcode"].ToString();
                                prog = dt.Rows[0]["progno"].ToString();
                                name = lname + ", " + fname + " " + mname[0] + ".";
                                Form1.ActiveForm.Hide();
                                adminAcct adminAcct = new adminAcct();
                                adminAcct.Show();
                            }
                            else
                            {
                                MessageBox.Show("Incorrect password.");
                            }

                        }
                        else
                        {
                            MessageBox.Show("You are not an admin.");
                        }
                    }
                }
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }
    }
}
